var express = require ('express');
var router = express.Router();
var router4 = require('./index.js')
var app = express(); 




app.listen(4000,()=>{
    console.log('PORT IS RUNNING ON 4000')
});


router.use('/det',router4);


module.exports = router;


